---
profile: smartdca-okf/0.3
type: domain-glossary
title: "Quasi-Gini SmartDCA Research"
description: "Canonical mathematical, financial, and knowledge-system vocabulary with its forbidden alternatives."
knowledge_role: canonical
status: stable
sources:
  - id: audit
    title: "Audit of the source out quasi-Gini functional"
    resource: research/notes/source-out-quasi-gini-audit
    source_kind: internal
  - id: prior-theory
    title: "Prior theory for the proposed corrected out quasi-Gini normalization"
    resource: research/notes/prior-theory-corrected-out-quasi-gini
    source_kind: internal
  - id: causal-boundary
    title: "Pathwise DCA dominance under causal budget feasibility"
    resource: research/notes/pathwise-dca-dominance-under-causal-budget
    source_kind: internal
  - id: guarded-score
    title: "A guarded corrected-mean SmartDCA rule"
    resource: research/notes/guarded-corrected-mean-smartdca
    source_kind: internal
  - id: ticket-12
    title: "Design a repository-root LLM-Wiki using OKF v0.2"
    resource: .scratch/smartdca/issues/12-design-repository-root-llm-wiki-okf
    source_kind: internal
  - id: okf-profile
    title: "SmartDCA Open Knowledge Format profile"
    resource: docs/knowledge/okf-profile
    source_kind: internal
  - id: homogeneity
    title: "Primary-source note: homogeneity of the canonical corrected out quasi-Gini mean"
    resource: research/notes/ticket-07-homogeneity-primary-sources
    source_kind: internal
  - id: guardrail
    title: "Sharp causal epsilon-DCA safety and its unit-coverage guardrail"
    resource: research/notes/sharp-epsilon-dca-safety-guardrail
    source_kind: internal
  - id: corrected-definition
    title: "The corrected out quasi-Gini mean"
    resource: research/definitions/corrected-out-quasi-gini-mean
    source_kind: internal
  - id: guarded-rule
    title: "The guarded corrected-mean SmartDCA rule"
    resource: research/definitions/guarded-corrected-mean-smartdca-rule
    source_kind: internal
  - id: classification
    title: "Exact mean classification of the source out quasi-Gini functional"
    resource: research/theorems/source-out-functional-mean-classification
    source_kind: internal
  - id: homogeneity-theorem
    title: "Homogeneity characterization of the corrected out quasi-Gini mean"
    resource: research/theorems/corrected-mean-homogeneity-characterization
    source_kind: internal
  - id: impossibility
    title: "Causal DCA dominance impossibility"
    resource: research/theorems/causal-dca-dominance-impossibility
    source_kind: internal
  - id: guardrail-theorem
    title: "Epsilon-DCA safety is exactly a causal unit-coverage guardrail"
    resource: research/theorems/epsilon-dca-safety-unit-guardrail
    source_kind: internal
  - id: two-purchase-boundary
    title: "Two-purchase guarded SmartDCA has an exact DCA boundary"
    resource: research/theorems/two-purchase-guarded-smartdca-boundary
    source_kind: internal
  - id: two-purchase-boundary-note
    title: "Exact two-purchase DCA win/loss boundary"
    resource: research/notes/two-purchase-dca-win-loss-boundary
    source_kind: internal
  - id: three-purchase-effect
    title: "Three-purchase guarded SmartDCA has an exact beta-sensitive DCA boundary"
    resource: research/theorems/three-purchase-corrected-mean-effect
    source_kind: internal
  - id: three-purchase-effect-note
    title: "Exact three-purchase corrected-mean effect"
    resource: research/notes/three-purchase-corrected-mean-effect
    source_kind: internal
  - id: source-conflicts
    title: "Conflicts across the OKF foundation sources"
    resource: research/synthesis/okf-foundation-source-conflicts
    source_kind: internal
generated:
  by: openai-codex/smartdca-wiki-0.1
  at: 2026-08-16T11:24:00Z
generation_run: urn:uuid:1d09cb3f-94ee-4b73-b0f2-393b4227167d
verified:
  - by: claude-code/smartdca-wiki-0.1
    at: 2026-08-16T07:46:00Z
    review_run: urn:uuid:b5b1666e-e77c-41a4-8781-fb0d5a965582
  - by: claude-code/smartdca-wiki-0.1
    at: 2026-08-16T07:46:00Z
    review_run: urn:uuid:da31a04e-0105-4659-9d05-895a4364b107
  - by: claude-code/smartdca-wiki-0.1
    at: 2026-08-16T07:55:00Z
    review_run: urn:uuid:e4ba41a1-1d8a-4cf6-b7a1-2c42a746b28f
  - by: claude-code/smartdca-wiki-0.1
    at: 2026-08-16T08:26:00Z
    review_run: urn:uuid:84b7d96d-6547-4bbf-b78e-f4334f5f3c41
  - by: claude-code/smartdca-wiki-0.1
    at: 2026-08-16T09:10:00Z
    review_run: urn:uuid:e26b6a0b-a55b-47f0-ae7f-88873e0ac8ab
  - by: claude-code/smartdca-wiki-0.1
    at: 2026-08-16T09:48:00Z
    review_run: urn:uuid:3b0e6083-180e-43b5-9314-df22687e68de
  - by: claude-code/smartdca-wiki-0.1
    at: 2026-08-16T10:06:00Z
    review_run: urn:uuid:6186d423-474a-44ee-8d3d-c36f938ad51a
  - by: claude-code/smartdca-wiki-0.1
    at: 2026-08-16T10:34:00Z
    review_run: urn:uuid:86b3e187-d6a2-44c5-997c-8c06f5fdbf87
  - by: claude-code/smartdca-wiki-0.1
    at: 2026-08-16T10:48:00Z
    review_run: urn:uuid:efbd9162-3fdb-43a6-a3c7-7ef6b7141532
  - by: openai-codex/smartdca-wiki-0.1
    at: 2026-08-16T11:14:00Z
    review_run: urn:uuid:5fdc289a-b5ff-4e1f-9d84-777c58a093f2
  - by: openai-codex/smartdca-wiki-0.1
    at: 2026-08-16T11:30:00Z
    review_run: urn:uuid:d55d437b-21a4-4ffb-b393-de516fb58c2d
---
# Quasi-Gini SmartDCA Research

This context develops a rigorous out quasi-Gini mean and studies whether it can generate a causal, fully funded SmartDCA strategy with exact accounting and a fair comparison against DCA.

## Language

**Out quasi-Gini functional**[^classification][^audit]:
The source-paper construction
\[
G^{f,\mathrm{out}}_{\alpha,\beta}(x)=
\left(
\frac{\sum_i x_i f(x_i)^{\alpha-1}}
     {\sum_i f(x_i)^\beta}
\right)^{1/(\alpha-\beta)},
\qquad \alpha\ne\beta,
\]
with \(\alpha=\rho+1\) and \(\beta=\gamma\). It is called a functional until its mean properties are established.
_Avoid_: Gini coefficient, out quasi-Gini mean when referring to the unverified source definition

**Corrected out quasi-Gini mean**[^corrected-definition][^prior-theory]:
The canonical numerator-preserving normalization
\[
\widehat G_{\alpha,\beta}^{f,\mathrm{out}}(x;w)
=\left(
\frac{\sum_i w_i x_i f(x_i)^{\alpha-1}}
     {\sum_i w_i x_i^{1-\alpha+\beta}f(x_i)^{\alpha-1}}
\right)^{1/(\alpha-\beta)}
\]
off the diagonal, with the parameter-continuous function-weighted geometric extension on
\(\alpha=\beta\). It is a weighted Bajraktarević mean, recovers weighted Gini
for \(f=\mathrm{id}\), and recovers the weighted source out quasi-Lehmer mean
when \(\alpha-\beta=1\).
_Avoid_: new mean class, repaired Eq. (70) without stating the normalization, automatic continuity/homogeneity/coordinate monotonicity

**Scale-homogeneous corrected subfamily**[^homogeneity-theorem][^homogeneity]:
At fixed off-diagonal parameters, the corrected mean is degree-one homogeneous exactly when \(\alpha=1\) (where the transform cancels) or \(f(t)=Ct^r\) under the project's increasing-transform assumption; on the diagonal, \(q=1\) is the analogous exception. One transform makes the whole two-parameter family homogeneous exactly in the power-transform case, which is a reparameterized classical weighted Gini family.
_Avoid_: homogeneity for a general increasing transform, transform novelty on the \(\alpha=q=1\) slice

**Weighted Bajraktarević identification**[^prior-theory]:
For \(d=\alpha-\beta\ne0\), the natural common-weight candidate
\[
\left(
\frac{\sum_i w_i x_i f(x_i)^{\alpha-1}}
     {\sum_i w_i x_i^{1-d}f(x_i)^{\alpha-1}}
\right)^{1/d}
\]
is exactly the weighted Bajraktarević mean
\(A_{t^{-d},\,t f(t)^{\alpha-1}}\). Its \(d=1\) slice is
Beckenbach--Gini--Lehmer/out quasi-Lehmer, and power transforms reduce to
classical weighted Gini means.
_Avoid_: new class of means, or Beckenbach--Gini as a name for the full family

**Sequentially admissible strategy**[^impossibility][^causal-boundary]:
A strategy whose purchase at time \(t\) depends only on deposits, prices, and portfolio state observed through time \(t\), after observing the current price and before observing any future price.
_Avoid_: future-aware strategy, ex-post normalized strategy

**Deposit budget**[^impossibility][^causal-boundary]:
Cash contributed through an exogenous deposit sequence; unused cash carries forward without interest, and purchases cannot exceed cash currently available.
_Avoid_: leverage, borrowing capacity

**DCA comparator**[^impossibility][^causal-boundary]:
The strategy that invests the entire new deposit at each purchase time at the current price, using the same deposit sequence and evaluation horizon as the candidate strategy.
_Avoid_: retrospectively budget-matched DCA

**Economic dominance**[^impossibility]:
Terminal wealth is at least that of the DCA comparator for every admissible positive price path and deposit sequence, and strictly greater for at least one admissible case.
_Avoid_: lower average cost alone

**Causal DCA impossibility boundary**[^impossibility][^causal-boundary]:
Under arbitrary finite positive price paths, the same exogenous deposits, and terminal wealth including cash, a causal fully funded buy-only strategy weakly dominates DCA only if it purchases each deposit exactly as DCA. A nontrivial positive result must restrict the path universe, relax causality, or weaken the performance criterion.
_Avoid_: DCA is optimal on each realized path, no strategy can ever beat DCA

**Epsilon-DCA safety**[^guardrail-theorem][^guardrail]:
For a fixed \(\varepsilon\in[0,1)\), terminal wealth including cash satisfies \(W^S\ge(1-\varepsilon)W^{DCA}\) for every admissible positive price path and deposit sequence. It is a uniform relative-wealth floor; it is not economic dominance when \(\varepsilon>0\).
_Avoid_: epsilon-dominance, near-superiority, guaranteed outperformance

**Epsilon-DCA unit guardrail**[^guardrail-theorem][^guardrail]:
With \(\lambda=1-\varepsilon\), the unit-coverage cushion \(Q_t^S-\lambda Q_t^{DCA}\) must remain nonnegative after every history; equivalently, each purchase must meet the sharp causal floor \([\lambda d_t-p_t(Q_{t-1}^S-\lambda Q_{t-1}^{DCA})]_+\). Purchases above that floor are the funded discretionary allocation.
_Avoid_: cash cushion, dominance budget, optional safety check

**Guarded corrected-mean score**[^guarded-rule]:
The canonical discretionary score anchors prices at \(p_1\), forms the lagged
dimensionless corrected-mean reference
\(R_{t-1}=\widehat G(p_1/p_1,\ldots,p_{t-1}/p_1)\), sets
\(r_t=(p_t/p_1)/R_{t-1}\), and uses
\[
a_t=\frac{1}{1+(f(r_t)/f(1))^{1-\alpha}}.
\]
It is a causal odds calibration inside the epsilon-DCA guardrail, neutral on
one-point and constant histories, and countercyclical in the current price when
\(f\) is nondecreasing and \(\alpha\le1\).
_Avoid_: ex-post normalization, an unnormalized nonhomogeneous price-level
reference, strict DCA outperformance without a proved criterion

**Two-purchase DCA boundary**[^two-purchase-boundary][^two-purchase-boundary-note]:
For the exact guarded rule, write \(q=p_2/p_1\), \(y=P/p_2\),
\(\delta=(1-\lambda)/2\),
\[
H=\delta d_1+d_2-[\lambda d_2-\delta d_1q]_+,\qquad
c=(1-a_2)H,\qquad g=\delta d_1(1-q).
\]
Then \(W_2^S-W_2^{DCA}=c-y(c-g)\). For
\(0<\lambda<1\) and a nonzero deposit pair, the rule wins below
\(c/(c-g)\), ties there, and loses above it when \(c-g>0\); if
\(c-g\le0\), every positive finite \(y\) is a win. At \(\lambda=1\) every
case ties. The singleton lagged reference makes \(\beta\) irrelevant at two
purchases.
_Avoid_: win probability, arbitrary-horizon boundary, evidence that
\(\beta\) improves the rule

**Three-purchase beta-sensitive DCA boundary**[^three-purchase-effect][^three-purchase-effect-note]:
For exactly three purchases, let \(b_\beta=a_3\) be the score formed from
the first two-input lagged reference, let \(H_3\) be the date-three
discretionary interval, and set
\[
c_\beta=(1-b_\beta)H_3,\qquad
g=\delta d_1\frac{p_3}{p_2}
  \left(1-\frac{p_2}{p_1}\right)
  +C_2\left(1-\frac{p_3}{p_2}\right),\qquad
y=\frac{P}{p_3}.
\]
Then \(W_3^S-W_3^{DCA}=c_\beta-y(c_\beta-g)\), giving the exact extended
threshold \(c_\beta/(c_\beta-g)\) when its denominator is positive and an
all-win slice otherwise. Changing \(\beta\) leaves the first two purchases
fixed but can change this threshold: an exact countercyclical witness flips
from a DCA loss at \(\beta=-1\) to a win at \(\beta=1\).
_Avoid_: beta superiority, monotone benefit from increasing beta,
arbitrary-horizon boundary, stochastic outperformance

**Terminal wealth**[^impossibility][^causal-boundary]:
Unspent cash plus the value of accumulated asset units at the common evaluation price.
_Avoid_: asset value with cash omitted

**Average acquisition cost**[^guarded-rule][^guarded-score]:
Total cash spent on the asset divided by total asset units acquired. It is a structural accounting quantity, not by itself a budget-equivalent performance measure.
_Avoid_: proof of economic superiority

## Knowledge system language

**Wiki repository**[^ticket-12]:
The complete SmartDCA research repository treated as a maintained knowledge system for people and agents.
_Avoid_: separate public website by default, disposable retrieval cache

**Knowledge concept**[^ticket-12]:
A self-contained maintained unit of knowledge with a stable identity and an explicit role in the project.
_Avoid_: retrieval chunk, arbitrary token window

**Knowledge role**[^okf-profile]:
The authority classification `canonical`, `evidence`, or `operational`; it distinguishes a preferred answer source from supporting material and project-control records.
_Avoid_: treating every document as equally authoritative

**Semantic concept boundary**[^okf-profile]:
A boundary justified by independent identity plus a need for reuse, provenance, verification, lifecycle, or retrieval across multiple questions.
_Avoid_: fixed-size split, one unit per heading

**Source summary**[^okf-profile]:
A concept covering exactly one ingested source, which records the origin, retrieval time, upstream version, and raw-byte fingerprint of each of that source's artifacts, and states what the source does and does not settle for this project. It never restates a mathematical result as project knowledge.
_Avoid_: digest of several sources, synthesis, editable copy of the source

**Immutable source artifact**[^okf-profile]:
An imported external source preserved without content edits after ingestion; a revised upstream edition is a new artifact.
_Avoid_: freezing internal research notes, silently replacing an edition

**Canonical home**[^okf-profile]:
The single canonical concept that agents prefer when answering a normalized research claim; evidence and operational records may retain local context but point back to it.
_Avoid_: deleting provenance-bearing repetition, several equally authoritative copies

**Synthesis concept**[^okf-profile]:
A high-risk concept that integrates multiple sources or project results, including explicit resolution of contradictory claims.
_Avoid_: silently rewriting a source summary, unresolved conflict presented as settled

**Superseded concept**[^okf-profile]:
A previously stable concept retained at its original identity with deprecated status, a reason, and a link to its successor.
_Avoid_: deleting stable knowledge, overwriting history without a successor

**Definition concept**[^okf-profile]:
The canonical home of one named construction: the object, its domain and parameter conditions, any limiting extension that makes it total, and the identities it must preserve. It does not carry the derivation.
_Avoid_: restating a proof, two competing canonical definitions of one construction

**Theorem concept**[^okf-profile]:
The canonical home of one proved statement: its hypotheses, the exact claim, whether the characterization is sharp, and what it does not establish. The proof, counterexamples, and literature positioning stay in the evidence note it cites.
_Avoid_: carrying the proof, a claim stated without its sharpness or scope limits

**Source authority ordering**[^source-conflicts]:
The four-class ordering that resolves which external source governs when they disagree: the normative specification alone defines conformance; examples and reference implementations evidence one reading and bind nothing; contemporaneous explanation is authoritative about rationale and not requirements; and a superseded announcement describes a version no longer in use. A pattern proposal sits outside the ordering and yields to the specification on any shared artifact.
_Avoid_: quoting a blog post or an example bundle as normative, treating a superseded announcement's field claims as current

**Structural freeze**[^okf-profile]:
A certification that nothing further is owed to the knowledge schema when it is made: no field, type, path, role, grammar, validator rule, or retrieval mechanism is known to be required. It governs the container and never the contents. It is revocable — a later schema change lapses the claim and restarts the supervised-ingest streak, and never invalidates a published concept.
_Avoid_: permanent schema lock, read-only corpus, a reason to avoid a change the work needs

**Independent semantic review**[^okf-profile]:
Verification by a reviewer distinct from the producing run, checking the claim against its sources, proof, computation, and declared scope.
_Avoid_: producer self-review, schema validation, confidence score

## Sources

Each term above is joined to the concept that governs its claim: the canonical home first, then the evidence note whose proof, counterexamples, or primary sources the canonical page deliberately does not carry. The four model terms — sequential admissibility, the deposit budget, the DCA comparator, and terminal wealth — share one canonical home, because the model they describe is stated once, in [Causal DCA dominance impossibility](research/theorems/causal-dca-dominance-impossibility.md), and inherited by reference everywhere else.

[^audit]: [Audit of the source out quasi-Gini functional](research/notes/source-out-quasi-gini-audit.md)
[^prior-theory]: [Prior theory for the proposed corrected out quasi-Gini normalization](research/notes/prior-theory-corrected-out-quasi-gini.md)
[^causal-boundary]: [Pathwise DCA dominance under causal budget feasibility](research/notes/pathwise-dca-dominance-under-causal-budget.md)
[^guarded-score]: [A guarded corrected-mean SmartDCA rule](research/notes/guarded-corrected-mean-smartdca.md)
[^ticket-12]: [Design a repository-root LLM-Wiki using OKF v0.2](.scratch/smartdca/issues/12-design-repository-root-llm-wiki-okf.md)
[^okf-profile]: [SmartDCA Open Knowledge Format profile](docs/knowledge/okf-profile.md)
[^corrected-definition]: [The corrected out quasi-Gini mean](research/definitions/corrected-out-quasi-gini-mean.md)
[^guarded-rule]: [The guarded corrected-mean SmartDCA rule](research/definitions/guarded-corrected-mean-smartdca-rule.md)
[^classification]: [Exact mean classification of the source out quasi-Gini functional](research/theorems/source-out-functional-mean-classification.md)
[^homogeneity-theorem]: [Homogeneity characterization of the corrected out quasi-Gini mean](research/theorems/corrected-mean-homogeneity-characterization.md)
[^impossibility]: [Causal DCA dominance impossibility](research/theorems/causal-dca-dominance-impossibility.md)
[^guardrail-theorem]: [Epsilon-DCA safety is exactly a causal unit-coverage guardrail](research/theorems/epsilon-dca-safety-unit-guardrail.md)
[^two-purchase-boundary]: [Two-purchase guarded SmartDCA has an exact DCA boundary](research/theorems/two-purchase-guarded-smartdca-boundary.md)
[^two-purchase-boundary-note]: [Exact two-purchase DCA win/loss boundary](research/notes/two-purchase-dca-win-loss-boundary.md)
[^three-purchase-effect]: [Three-purchase guarded SmartDCA has an exact beta-sensitive DCA boundary](research/theorems/three-purchase-corrected-mean-effect.md)
[^three-purchase-effect-note]: [Exact three-purchase corrected-mean effect](research/notes/three-purchase-corrected-mean-effect.md)
[^source-conflicts]: [Conflicts across the OKF foundation sources](research/synthesis/okf-foundation-source-conflicts.md)
[^homogeneity]: [Primary-source note on homogeneity of the canonical corrected mean](research/notes/ticket-07-homogeneity-primary-sources.md)
[^guardrail]: [Sharp causal epsilon-DCA safety and its unit-coverage guardrail](research/notes/sharp-epsilon-dca-safety-guardrail.md)
